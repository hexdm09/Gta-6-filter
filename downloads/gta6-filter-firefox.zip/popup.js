// src/matcher.ts
var decimalDigits = /\p{Nd}/gu;
var decimalDigit = /^\p{Nd}$/u;
var digitValues = /* @__PURE__ */ new Map();
function toAsciiDigit(digit) {
  if (digit >= "0" && digit <= "9") return digit;
  const cached = digitValues.get(digit);
  if (cached !== void 0) return cached;
  const code = digit.codePointAt(0);
  let start = code;
  while (start > 0 && decimalDigit.test(String.fromCodePoint(start - 1))) start--;
  const value = String((code - start) % 10);
  digitValues.set(digit, value);
  return value;
}
function normalize(text) {
  return text.normalize("NFKC").toLowerCase().replace(/[\p{Cf}\u0640\u064b-\u065f\u0670]/gu, "").replace(decimalDigits, toAsciiDigit).replace(/\s+/gu, " ").trim();
}
var separator = "[\\s._·・\\p{Pd}]*";
var latinOrCyrillic = "[\\p{Script=Latin}\\p{Script=Cyrillic}\\p{Nd}]";
var standardTitle = new RegExp(
  "(?<!" + latinOrCyrillic + ")(?:gta|гта|grand" + separator + "theft" + separator + "auto)" + separator + "(?:6|vi)(?!" + latinOrCyrillic + ")",
  "u"
);
var localizedNames = [
  "侠盗猎车手",
  "俠盜獵車手",
  "俠盜獵車",
  "侠盗猎车",
  "横行霸道",
  "橫行霸道",
  "グランド セフト オート",
  "グラセフ",
  "그랜드 테프트 오토",
  "지티에이",
  "جراند ثفت أوتو",
  "جراند ثفت اوتو",
  "غراند ثفت أوتو",
  "غراند ثفت اوتو",
  "جي تي إيه",
  "جي تي اي",
  "जीटीए",
  "ग्रैंड थेफ्ट ऑटो",
  "ग्रैंड थेफ़्ट ऑटो"
];
var localizedTitle = new RegExp(
  "(?:" + localizedNames.map((name) => normalize(name).split(" ").join(separator)).join("|") + ")" + separator + "(?:6|vi)(?!" + latinOrCyrillic + ")",
  "u"
);
function cleanTerms(terms2) {
  const unique = /* @__PURE__ */ new Map();
  for (const term of terms2) {
    const normalized = normalize(term);
    if (normalized && !unique.has(normalized)) unique.set(normalized, term.trim());
  }
  return [...unique.values()];
}

// src/settings.ts
var sites = ["youtube", "reddit", "x"];
var extension = globalThis.browser ?? chrome;
var keys = ["enabled", ...sites, "terms"];
function parseSettings(data) {
  return {
    enabled: data.enabled !== false,
    youtube: data.youtube !== false,
    reddit: data.reddit !== false,
    x: data.x !== false,
    terms: cleanTerms(Array.isArray(data.terms) ? data.terms.filter((term) => typeof term === "string") : [])
  };
}
async function readSettings() {
  return parseSettings(await extension.storage.local.get(keys));
}
function message(key) {
  return extension.i18n.getMessage(key);
}

// src/popup.ts
document.documentElement.lang = message("@@ui_locale").replaceAll("_", "-") || "en";
document.documentElement.dir = message("@@bidi_dir") || "ltr";
for (const element of document.querySelectorAll("[data-i18n]")) {
  element.textContent = message(element.dataset.i18n);
}
var form = document.querySelector("form");
var terms = form.querySelector("textarea");
var save = form.querySelector("button");
var status = document.querySelector("#status");
var names = ["enabled", ...sites];
function showStatus(key, error = false) {
  status.textContent = key ? message(key) : "";
  status.toggleAttribute("data-error", error);
}
for (const name of names) {
  const control = document.querySelector("#" + name);
  control.addEventListener("change", async () => {
    const value = control.checked;
    control.disabled = true;
    try {
      await extension.storage.local.set({ [name]: value });
      showStatus("");
    } catch {
      control.checked = !value;
      showStatus("storageError", true);
    } finally {
      control.disabled = false;
    }
  });
}
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  save.disabled = true;
  const input = terms.value;
  const values = cleanTerms(input.split(/\r?\n/));
  try {
    await extension.storage.local.set({ terms: values });
    if (terms.value === input) {
      terms.value = values.join("\n");
      showStatus("saved");
    }
  } catch {
    showStatus("storageError", true);
  } finally {
    save.disabled = false;
  }
});
terms.addEventListener("input", () => showStatus(""));
try {
  const settings = await readSettings();
  for (const name of names) {
    const control = document.querySelector("#" + name);
    control.checked = settings[name];
    control.disabled = false;
  }
  terms.value = settings.terms.join("\n");
  terms.disabled = false;
  save.disabled = false;
} catch {
  showStatus("storageError", true);
}
