"use strict";
(() => {
  // src/matcher.ts
  var decimalDigits = /\p{Nd}/gu;
  var decimalDigit = /^\p{Nd}$/u;
  var digitValues = /* @__PURE__ */ new Map();
  function toAsciiDigit(digit) {
    if (digit >= "0" && digit <= "9") return digit;
    const cached = digitValues.get(digit);
    if (cached !== void 0) return cached;
    const code = digit.codePointAt(0);
    let start2 = code;
    while (start2 > 0 && decimalDigit.test(String.fromCodePoint(start2 - 1))) start2--;
    const value = String((code - start2) % 10);
    digitValues.set(digit, value);
    return value;
  }
  function normalize(text) {
    return text.normalize("NFKC").toLowerCase().replace(/[\p{Cf}\u0640\u064b-\u065f\u0670]/gu, "").replace(decimalDigits, toAsciiDigit).replace(/\s+/gu, " ").trim();
  }
  var separator = "[\\s._·・\\p{Pd}]*";
  var latinOrCyrillic = "[\\p{Script=Latin}\\p{Script=Cyrillic}\\p{Nd}]";
  var standardTitle = new RegExp(
    "(?<!" + latinOrCyrillic + ")(?:gta|гта|grand" + separator + "theft" + separator + "auto)" + separator + "(?:6|vi)(?!" + latinOrCyrillic + ")",
    "u"
  );
  var topicalHashtag = /#(?:gta|гта|grandtheftauto)_?(?:6|vi)_?(?:(?:leaks?|spoilers?|gameplay|news|trailers?|updates?|rockstargames|утечк[аи]|спойлер[ыи]?))+(?![\p{Script=Latin}\p{Script=Cyrillic}\p{Nd}])/u;
  var localizedNames = [
    "侠盗猎车手",
    "俠盜獵車手",
    "俠盜獵車",
    "侠盗猎车",
    "横行霸道",
    "橫行霸道",
    "グランド セフト オート",
    "グラセフ",
    "그랜드 테프트 오토",
    "지티에이",
    "جراند ثفت أوتو",
    "جراند ثفت اوتو",
    "غراند ثفت أوتو",
    "غراند ثفت اوتو",
    "جي تي إيه",
    "جي تي اي",
    "जीटीए",
    "ग्रैंड थेफ्ट ऑटो",
    "ग्रैंड थेफ़्ट ऑटो"
  ];
  var localizedTitle = new RegExp(
    "(?:" + localizedNames.map((name) => normalize(name).split(" ").join(separator)).join("|") + ")" + separator + "(?:6|vi)(?!" + latinOrCyrillic + ")",
    "u"
  );
  function cleanTerms(terms) {
    const unique = /* @__PURE__ */ new Map();
    for (const term of terms) {
      const normalized = normalize(term);
      if (normalized && !unique.has(normalized)) unique.set(normalized, term.trim());
    }
    return [...unique.values()];
  }
  function createMatcher(terms) {
    const customTerms = cleanTerms(terms).map(normalize);
    return (fields) => fields.some((field) => {
      const text = normalize(field);
      return standardTitle.test(text) || topicalHashtag.test(text) || localizedTitle.test(text) || customTerms.some((term) => text.includes(term));
    });
  }

  // src/settings.ts
  var sites = ["youtube", "reddit", "x"];
  var extension = globalThis.browser ?? chrome;
  var keys = ["enabled", ...sites, "terms"];
  function parseSettings(data) {
    return {
      enabled: data.enabled !== false,
      youtube: data.youtube !== false,
      reddit: data.reddit !== false,
      x: data.x !== false,
      terms: cleanTerms(Array.isArray(data.terms) ? data.terms.filter((term) => typeof term === "string") : [])
    };
  }
  async function readSettings() {
    return parseSettings(await extension.storage.local.get(keys));
  }
  function watchSettings(update) {
    let version = 0;
    const refresh = async () => {
      const request = ++version;
      try {
        const settings = await readSettings();
        if (request === version) update(settings);
      } catch {
        if (request === version) update(parseSettings({}));
      }
    };
    extension.storage.onChanged.addListener((changes, area) => {
      if (area === "local" && keys.some((key) => key in changes)) void refresh();
    });
    void refresh();
  }
  function message(key) {
    return extension.i18n.getMessage(key);
  }

  // src/sites/shared.ts
  function fieldsFrom(root, selector, boundary) {
    return Array.from(root.querySelectorAll(selector)).flatMap((entry) => {
      if (entry.closest("[data-gta6f-ui]")) return [];
      if (boundary && entry.closest(boundary) !== root) return [];
      return [entry.textContent, entry.getAttribute("title"), entry.getAttribute("aria-label"), entry.getAttribute("alt")].filter((value) => Boolean(value?.trim()));
    });
  }
  function values(...fields) {
    return fields.filter((value) => Boolean(value?.trim()));
  }
  function linkUrl(link, base) {
    const href = link?.getAttribute("href");
    if (!href) return null;
    try {
      const url = new URL(href, base);
      return url.protocol === "https:" && url.hostname === base.hostname ? url : null;
    } catch {
      return null;
    }
  }
  function onSurface(element) {
    return !element.closest('[hidden], [aria-hidden="true"], [inert], [data-gta6f-ui]');
  }
  function watchId(url) {
    if (!url) return null;
    const id = url.pathname === "/watch" ? url.searchParams.get("v") : url.pathname.match(/^\/shorts\/([\w-]+)\/?$/)?.[1];
    return id && /^[\w-]+$/.test(id) ? id : null;
  }

  // src/sites/reddit.ts
  var posts = "shreddit-post, faceplate-tracker[noun='post']:not(:has(shreddit-post), shreddit-post *)";
  var comments = "shreddit-comment";
  var searchResults = "search-telemetry-tracker:not(:has(shreddit-post, faceplate-tracker[noun='post']), shreddit-post *, faceplate-tracker[noun='post'] *)";
  var cards = [posts, comments, searchResults].join(", ");
  var communities = /* @__PURE__ */ new Set(["gta6", "gtavi", "gta6leaks", "gtavileaks", "grandtheftauto6", "grandtheftautovi"]);
  function communityName(name) {
    return normalize(name).replace(/^\/?r\//, "").replace(/[^a-z0-9]/g, "");
  }
  function routeCommunity(path) {
    return path.match(/^\/r\/([^/]+)/i)?.[1];
  }
  function permalinkId(path) {
    return path.match(/\/comments\/([a-z0-9]+)(?:\/|$)/i)?.[1]?.toLowerCase();
  }
  var postKey = (id) => "reddit:post:" + id;
  function readCard(element, url) {
    if (element.matches(comments)) {
      const fields2 = fieldsFrom(element, "[slot='comment'], [slot='comment-content'], .md", comments);
      const id2 = element.getAttribute("thingid") ?? element.getAttribute("id");
      return {
        fields: fields2,
        ready: fields2.length > 0,
        key: id2 ? "reddit:comment:" + id2 : null,
        topical: communities.has(communityName(routeCommunity(url.pathname) ?? ""))
      };
    }
    if (element.matches(searchResults) && !element.querySelector("a[href*='/comments/']")) {
      return { fields: [], ready: true, key: null };
    }
    const link = element.querySelector("a[slot='title'], a[data-testid='post-title'], a[href*='/comments/']");
    const path = element.getAttribute("permalink") ?? linkUrl(link, url)?.pathname ?? "";
    const community = element.getAttribute("subreddit-prefixed-name") ?? element.getAttribute("subreddit-name") ?? routeCommunity(path) ?? linkUrl(element.querySelector("a[href^='/r/']"), url)?.pathname.match(/^\/r\/([^/]+)/i)?.[1] ?? routeCommunity(url.pathname);
    const id = permalinkId(path) ?? element.getAttribute("thingid")?.match(/^t3_([a-z0-9]+)$/i)?.[1];
    const headings = [
      ...values(element.getAttribute("post-title")),
      ...fieldsFrom(element, "[slot='title'], [data-testid='post-title'], h1, h2, h3")
    ];
    const fields = [...headings, ...fieldsFrom(
      element,
      "[slot='text-body'], [slot='text-content'], [slot='post-media-container'] img[alt], [data-testid='post-content'], .md, img[alt]"
    )];
    return {
      fields,
      ready: headings.length > 0 || fields.length > 0,
      topical: Boolean(community && communities.has(communityName(community))),
      key: id ? postKey(id) : null
    };
  }
  var reddit = {
    site: "reddit",
    hosts: ["www.reddit.com", "reddit.com"],
    cards,
    readCard,
    directRoute(url) {
      const id = permalinkId(url.pathname);
      return id ? { id, key: postKey(id), kind: "post" } : null;
    },
    readDirect(document2, route, url) {
      for (const element of document2.querySelectorAll(posts)) {
        if (!onSurface(element)) continue;
        const candidate = readCard(element, url);
        if (candidate.key === route.key) return { ...candidate, source: element };
      }
      const topical = communities.has(communityName(routeCommunity(url.pathname) ?? ""));
      return topical ? { key: route.key, fields: [], ready: false, topical } : null;
    }
  };

  // src/sites/x.ts
  var cards2 = "article[data-testid='tweet']";
  var statusKey = (id) => "x:status:" + id;
  var ownStatusLinks = [
    "a[href*='/status/']:has(time)",
    "[data-testid='User-Name'] a[href*='/status/']"
  ].join(", ");
  function statusId(path) {
    return path?.match(/\/status\/(\d+)(?:\/|$)/)?.[1];
  }
  function readCard2(element, url) {
    const link = Array.from(element.querySelectorAll(ownStatusLinks)).find((anchor) => !anchor.closest("[data-testid='quoteTweet'], [data-testid='card.wrapper']")) ?? null;
    const path = linkUrl(link, url)?.pathname;
    const id = statusId(path);
    const fields = fieldsFrom(element, [
      "[data-testid='tweetText']",
      "[data-testid='card.wrapper']",
      "[data-testid='quoteTweet']"
    ].join(", "));
    const labels = fieldsFrom(element, "[data-testid='tweetPhoto'] img[alt], [data-testid='videoPlayer'] [aria-label]");
    const metadata = [...fields, ...labels];
    return { fields: metadata, ready: fields.length > 0, key: id ? statusKey(id) : null };
  }
  var x = {
    site: "x",
    hosts: ["x.com", "www.x.com", "twitter.com", "www.twitter.com"],
    cards: cards2,
    readCard: readCard2,
    directRoute(url) {
      const id = statusId(url.pathname);
      return id ? { id, key: statusKey(id), kind: "status" } : null;
    },
    readDirect(document2, route, url) {
      for (const element of document2.querySelectorAll(cards2)) {
        if (!onSurface(element)) continue;
        const candidate = readCard2(element, url);
        if (candidate.key === route.key) return { ...candidate, source: element };
      }
      return null;
    }
  };

  // src/sites/youtube.ts
  var videoContainers = [
    "ytd-rich-item-renderer",
    "ytd-video-renderer",
    "ytd-compact-video-renderer",
    "ytd-grid-video-renderer",
    "ytd-reel-item-renderer",
    "ytd-reel-video-renderer"
  ].join(", ");
  var cards3 = [
    videoContainers,
    "yt-lockup-view-model:not(:is(" + videoContainers + ") *)",
    "ytm-shorts-lockup-view-model:not(:is(" + videoContainers + ") *)",
    "ytd-comment-view-model",
    "ytd-comment-renderer:not(ytd-comment-view-model *)"
  ].join(", ");
  var titles = [
    "#video-title",
    "#video-title-link",
    "h3",
    ".yt-lockup-metadata-view-model__heading",
    ".shortsLockupViewModelHostMetadataTitle",
    "#reel-video-title",
    "yt-reel-metapanel-view-model h2"
  ].join(", ");
  var supplemental = [
    "#description-text",
    "#description-inline-expander",
    ".metadata-snippet-text",
    "a[href^='/hashtag/']",
    "img[alt]",
    "video[aria-label]"
  ].join(", ");
  var commentSelector = "ytd-comment-view-model, ytd-comment-renderer";
  var videoKey = (id) => "youtube:video:" + id;
  function cardId(element, url) {
    const explicit = element.getAttribute("video-id");
    if (explicit && /^[\w-]+$/.test(explicit)) return explicit;
    const link = element.querySelector("a[href^='/watch?'], a[href^='/shorts/']");
    return watchId(linkUrl(link, url));
  }
  function readCard3(element, url) {
    if (element.matches(commentSelector)) {
      const fields2 = fieldsFrom(element, "#content-text, #content, .yt-core-attributed-string", commentSelector);
      const id2 = element.getAttribute("comment-id") ?? element.getAttribute("id");
      return { fields: fields2, ready: fields2.length > 0, key: id2 ? "youtube:comment:" + id2 : null };
    }
    const id = cardId(element, url);
    const headings = fieldsFrom(element, titles);
    const fields = [...headings, ...fieldsFrom(element, supplemental)];
    return { fields, ready: headings.length > 0, key: id ? videoKey(id) : null };
  }
  var youtube = {
    site: "youtube",
    hosts: ["www.youtube.com", "youtube.com"],
    cards: cards3,
    readCard: readCard3,
    directRoute(url) {
      const id = watchId(url);
      return id ? { id, key: videoKey(id), kind: url.pathname === "/watch" ? "watch" : "shorts" } : null;
    },
    readDirect(document2, route, url) {
      if (route.kind === "shorts") {
        const shorts = document2.querySelectorAll("ytd-reel-video-renderer[is-active], ytd-reel-video-renderer[active]");
        const active = Array.from(shorts).find((element) => onSurface(element) && cardId(element, url) === route.id);
        return active ? { ...readCard3(active, url), source: active } : null;
      }
      const watch = Array.from(document2.querySelectorAll("ytd-watch-flexy")).find(onSurface);
      if (!watch) return null;
      const heading = watch.querySelector("ytd-watch-metadata #title h1, ytd-watch-metadata h1, #primary #title h1");
      const metadataId = heading?.closest("ytd-watch-metadata")?.getAttribute("video-id");
      const id = metadataId ?? watch.getAttribute("video-id");
      if (id !== route.id) return null;
      const title = values(heading?.textContent, heading?.getAttribute("title"));
      const fields = [...title, ...fieldsFrom(watch, "ytd-watch-metadata #description-inline-expander, ytd-watch-metadata #description, ytd-watch-metadata a[href^='/hashtag/']")];
      return { fields, ready: title.length > 0, key: route.key, source: watch };
    }
  };

  // src/sites/index.ts
  var adapters = [youtube, reddit, x];

  // src/content.ts
  var stateAttribute = "data-gta6f-state";
  var offAttribute = "data-gta6f-off";
  var directAttribute = "data-gta6f-direct";
  var panelSelector = "[data-gta6f-ui]";
  var waitForMetadata = 2e3;
  var observedAttributes = [
    "href",
    "title",
    "aria-label",
    "alt",
    "video-id",
    "comment-id",
    "thingid",
    "post-title",
    "permalink",
    "subreddit-name",
    "subreddit-prefixed-name",
    "is-active",
    "active",
    "hidden",
    "aria-hidden",
    "inert",
    "id",
    "data-testid",
    "noun",
    "slot"
  ];
  function createPanel(kind) {
    const panel = document.createElement("section");
    panel.dataset.gta6fUi = kind;
    panel.dir = message("@@bidi_dir") || "ltr";
    const text = document.createElement("p");
    text.setAttribute("role", "status");
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = message("reveal");
    panel.append(text, button);
    return panel;
  }
  function updatePanel(panel, phase) {
    if (panel.dataset.gta6fPhase === phase) return;
    panel.dataset.gta6fPhase = phase;
    panel.querySelector("p").textContent = message(phase === "blocked" ? "hidden" : phase);
    panel.querySelector("button").hidden = phase === "pending";
  }
  function start(adapter2) {
    const cards4 = /* @__PURE__ */ new Map();
    const pendingCards = /* @__PURE__ */ new Set();
    const revealedKeys = /* @__PURE__ */ new Set();
    const pausedByGuard = /* @__PURE__ */ new Set();
    const neutralTitle = message("appName");
    let url = new URL(location.href);
    let navigation = pageKey(url);
    let enabled = true;
    let settingsReady = false;
    let matches = createMatcher([]);
    let direct = newDirect(adapter2.directRoute(url));
    let directPanel;
    let siteTitle;
    let deadlineTimer;
    function pageKey(current) {
      return adapter2.directRoute(current)?.key ?? current.pathname + current.search;
    }
    function newDirect(route, staleWatchTitle) {
      return route ? { route, phase: "pending", expires: performance.now() + waitForMetadata, staleWatchTitle } : null;
    }
    function setPageCover() {
      const cover = Boolean(enabled && direct && direct.phase !== "open");
      document.documentElement?.toggleAttribute(offAttribute, !enabled);
      document.documentElement?.toggleAttribute(directAttribute, cover);
      if (cover && document.head && document.title !== neutralTitle) {
        siteTitle = document.title;
        document.title = neutralTitle;
      } else if (!cover && siteTitle !== void 0) {
        if (document.title === neutralTitle) document.title = siteTitle;
        siteTitle = void 0;
      }
      if (!cover || !document.body || !direct) {
        directPanel?.remove();
        return;
      }
      if (!directPanel) {
        directPanel = createPanel("direct");
        directPanel.querySelector("button").addEventListener("click", (event) => {
          if (!event.isTrusted || !direct || direct.phase === "pending") return;
          event.stopPropagation();
          revealedKeys.add(direct.route.key);
          scan();
        });
      }
      updatePanel(directPanel, direct.phase);
      if (directPanel.parentElement !== document.body) document.body.append(directPanel);
    }
    function allowPlayback() {
      for (const media of pausedByGuard) {
        if (!media.isConnected) continue;
        void media.play()?.catch(() => {
        });
      }
      pausedByGuard.clear();
    }
    function reviewDirect(now) {
      if (!enabled || !direct) {
        setPageCover();
        return;
      }
      if (!settingsReady) {
        setPageCover();
        return;
      }
      const { route } = direct;
      const revealed = revealedKeys.has(route.key);
      const candidate = revealed ? null : adapter2.readDirect(document, route, url);
      direct.source = candidate?.source;
      const title = candidate?.fields[0];
      const freshMetadata = candidate?.ready && (direct.staleWatchTitle === void 0 || title !== direct.staleWatchTitle);
      const oldPhase = direct.phase;
      if (revealed) {
        direct.phase = "open";
      } else if (candidate?.topical || candidate && matches(candidate.fields)) {
        direct.phase = "blocked";
      } else if (freshMetadata) {
        direct.phase = "open";
      } else {
        direct.phase = now < direct.expires ? "pending" : "unverified";
      }
      if (route.kind === "watch" && freshMetadata) {
        direct.watchTitle = title;
        direct.staleWatchTitle = void 0;
      }
      setPageCover();
      if (direct.phase === "open" && oldPhase !== "open" && !revealed) allowPlayback();
      if (direct.phase === "blocked" || revealed) pausedByGuard.clear();
      if (direct.phase !== "open") {
        for (const media of document.querySelectorAll("video, audio")) guardPlayback(media);
      }
    }
    function clearCard(element, card) {
      element.removeAttribute(stateAttribute);
      card.panel?.remove();
      cards4.delete(element);
      pendingCards.delete(element);
    }
    function showCardState(element, card) {
      const display = card.phase === "open" ? "open" : "closed";
      if (element.getAttribute(stateAttribute) !== display) element.setAttribute(stateAttribute, display);
      if (card.phase !== "blocked" || !element.parentElement) {
        card.panel?.remove();
        return;
      }
      if (!card.panel) {
        card.panel = createPanel("card");
        card.panel.querySelector("button").addEventListener("click", (event) => {
          if (!event.isTrusted || card.phase !== "blocked" || !element.isConnected) return;
          event.stopPropagation();
          if (card.key) revealedKeys.add(card.key);
          else card.revealedStamp = card.stamp;
          scan();
        });
      }
      updatePanel(card.panel, card.phase);
      if (card.panel.nextElementSibling !== element) element.before(card.panel);
      for (const media of element.querySelectorAll("video, audio")) media.pause();
    }
    function reviewCard(element, now) {
      const previous = cards4.get(element);
      if (!element.isConnected || !element.matches(adapter2.cards)) {
        if (previous) clearCard(element, previous);
        return;
      }
      const entry = adapter2.readCard(element, url);
      const card = previous ?? { key: entry.key, expires: now + waitForMetadata, phase: "pending", stamp: "" };
      if (card.key !== entry.key) {
        card.stalePrimary = card.primary;
        card.key = entry.key;
        card.expires = now + waitForMetadata;
        card.revealedStamp = void 0;
      }
      const freshMetadata = entry.ready && (card.stalePrimary === void 0 || entry.fields[0] !== card.stalePrimary);
      if (freshMetadata) {
        card.primary = entry.fields[0];
        card.stalePrimary = void 0;
      }
      card.stamp = entry.key === null ? JSON.stringify(entry.fields) : "";
      const revealed = entry.key ? revealedKeys.has(entry.key) : card.revealedStamp === card.stamp;
      if (revealed) card.phase = "open";
      else if (entry.topical || matches(entry.fields)) card.phase = "blocked";
      else card.phase = freshMetadata || now >= card.expires ? "open" : "pending";
      cards4.set(element, card);
      if (card.phase === "pending") pendingCards.add(element);
      else pendingCards.delete(element);
      showCardState(element, card);
    }
    function scheduleDeadline() {
      window.clearTimeout(deadlineTimer);
      let next = direct?.phase === "pending" ? direct.expires : Infinity;
      for (const element of pendingCards) next = Math.min(next, cards4.get(element).expires);
      if (!Number.isFinite(next)) return;
      deadlineTimer = window.setTimeout(() => {
        const now = performance.now();
        update([...pendingCards].filter((element) => (cards4.get(element)?.expires ?? Infinity) <= now));
      }, Math.max(1, Math.ceil(next - performance.now())));
    }
    function checkNavigation() {
      if (url.href === location.href) return false;
      url = new URL(location.href);
      const next = pageKey(url);
      const nextRoute = adapter2.directRoute(url);
      if (next === navigation) return false;
      navigation = next;
      revealedKeys.clear();
      const staleWatchTitle = direct?.route.kind === "watch" ? direct.watchTitle ?? direct.staleWatchTitle : void 0;
      direct = newDirect(nextRoute, staleWatchTitle);
      for (const card of cards4.values()) card.revealedStamp = void 0;
      pausedByGuard.clear();
      setPageCover();
      return true;
    }
    function update(changed, full = false, directChanged = true) {
      const navigated = checkNavigation();
      if (!enabled || !settingsReady) {
        setPageCover();
        return;
      }
      const now = performance.now();
      if (navigated || full || directChanged) reviewDirect(now);
      else setPageCover();
      if (navigated || full) {
        for (const [element, card] of cards4) {
          if (!element.isConnected || !element.matches(adapter2.cards)) clearCard(element, card);
        }
        changed = document.querySelectorAll(adapter2.cards);
      }
      for (const element of changed) reviewCard(element, now);
      scheduleDeadline();
    }
    function scan() {
      update([], true);
    }
    function guardPlayback(media) {
      if (!enabled || media.paused) return;
      if (direct && direct.phase !== "open") {
        if (direct.phase !== "blocked") pausedByGuard.add(media);
        media.pause();
      } else if (media.closest(adapter2.cards)?.getAttribute(stateAttribute) === "closed") {
        media.pause();
      }
    }
    function mediaStarted(event) {
      if (url.href !== location.href) scan();
      if (event.target instanceof HTMLMediaElement) guardPlayback(event.target);
    }
    function collectAncestors(element, changed) {
      for (let candidate = element?.closest(adapter2.cards); candidate; candidate = candidate.parentElement?.closest(adapter2.cards)) {
        changed.add(candidate);
      }
      if (element && cards4.has(element)) changed.add(element);
    }
    function collectTree(node, changed) {
      if (!(node instanceof Element) || node.matches(panelSelector)) return;
      if (node.matches(adapter2.cards) || cards4.has(node)) changed.add(node);
      for (const descendant of node.querySelectorAll(adapter2.cards + ", [" + stateAttribute + "]")) {
        changed.add(descendant);
      }
    }
    const observer = new MutationObserver((mutations) => {
      if (!enabled || !settingsReady) {
        setPageCover();
        return;
      }
      const changed = /* @__PURE__ */ new Set();
      let relevant = false;
      const source = direct?.source;
      let directChanged = !source?.isConnected;
      for (const mutation of mutations) {
        const element = mutation.target instanceof Element ? mutation.target : mutation.target.parentElement;
        if (element?.closest(panelSelector)) continue;
        if (mutation.type === "childList") {
          const children = [...mutation.addedNodes, ...mutation.removedNodes];
          if (children.length && children.every((node) => node instanceof Element && node.matches(panelSelector))) continue;
          for (const child of children) collectTree(child, changed);
        }
        relevant = true;
        if (source && element && (source.contains(element) || mutation.type === "attributes" && element.contains(source))) {
          directChanged = true;
        }
        collectAncestors(element, changed);
      }
      if (relevant) update(changed, false, directChanged);
    });
    function applySettings(settings) {
      settingsReady = true;
      const active = settings.enabled && settings[adapter2.site];
      const wasEnabled = enabled;
      enabled = active;
      matches = createMatcher(settings.terms);
      if (!enabled) {
        for (const [element, card] of cards4) clearCard(element, card);
        window.clearTimeout(deadlineTimer);
        pausedByGuard.clear();
      } else if (!wasEnabled) {
        direct = newDirect(adapter2.directRoute(new URL(location.href)));
      }
      scan();
    }
    setPageCover();
    observer.observe(document, {
      subtree: true,
      childList: true,
      characterData: true,
      attributes: true,
      attributeFilter: observedAttributes
    });
    document.addEventListener("play", mediaStarted, true);
    document.addEventListener("playing", mediaStarted, true);
    document.addEventListener("yt-navigate-finish", scan);
    window.addEventListener("popstate", scan);
    const navigationApi = window.navigation;
    navigationApi?.addEventListener("currententrychange", scan);
    watchSettings(applySettings);
  }
  var adapter = adapters.find((candidate) => candidate.hosts.includes(location.hostname));
  if (adapter) start(adapter);
})();
